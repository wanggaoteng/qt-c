%{Cpp:LicenseTemplate}\
